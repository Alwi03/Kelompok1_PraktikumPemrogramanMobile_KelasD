package com.tubes.perkuliahan.k4.networks

import com.tubes.perkuliahan.k4.model.Mahasiswa

data class MahasiswaGetResponse(
    val data: List<Mahasiswa>? = null
)
