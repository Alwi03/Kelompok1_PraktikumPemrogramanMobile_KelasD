package com.tubes.perkuliahan.k4.networks

import com.tubes.perkuliahan.k4.model.MataKuliah

data class MataKuliahGetResponse(
    val data: List<MataKuliah>? = null
)