package com.tubes.perkuliahan.k4.networks

import com.tubes.perkuliahan.k4.model.MataKuliah

data class MataKuliahSingleGetResponse(
    val data: MataKuliah? = null
)