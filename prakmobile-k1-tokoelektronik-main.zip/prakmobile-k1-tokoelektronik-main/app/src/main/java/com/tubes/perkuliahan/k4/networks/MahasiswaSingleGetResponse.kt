package com.tubes.perkuliahan.k4.networks

import com.tubes.perkuliahan.k4.model.Mahasiswa

data class MahasiswaSingleGetResponse(
    val data: Mahasiswa? = null
)