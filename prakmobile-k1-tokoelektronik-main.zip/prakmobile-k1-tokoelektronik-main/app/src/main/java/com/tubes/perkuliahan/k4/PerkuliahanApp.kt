package com.tubes.perkuliahan.k4

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class PerkuliahanApp : Application()