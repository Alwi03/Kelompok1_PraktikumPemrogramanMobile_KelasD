package com.tubes.perkuliahan.k4.networks

import com.tubes.perkuliahan.k4.data.model.Dosen

data class DosenGetResponse(
    val data: List<Dosen>? = null
)