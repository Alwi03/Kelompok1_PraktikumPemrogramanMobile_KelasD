package com.tubes.perkuliahan.k4.repository

interface Repository