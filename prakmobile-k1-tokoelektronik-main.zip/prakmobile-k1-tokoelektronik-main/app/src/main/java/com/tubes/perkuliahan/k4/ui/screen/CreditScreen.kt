package com.tubes.perkuliahan.k4.ui.screen

import androidx.compose.runtime.Composable

@Composable
fun CreditScren(){

}